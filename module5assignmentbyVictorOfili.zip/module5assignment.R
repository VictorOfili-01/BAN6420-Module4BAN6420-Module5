# write code for importing dataset
library(readr)
bc_data <- read.csv("breast_cancer.csv", stringsAsFactors = FALSE)
head(bc_data)

# Perform Principal Component Analysis (PCA) on the dataset
# Remove non-numeric columns if present
numeric_data <- bc_data[sapply(bc_data, is.numeric)]

# Standardize the numeric data
scaled_data <- scale(numeric_data)

# Apply PCA
pca_result <- prcomp(scaled_data, center = TRUE, scale. = TRUE)

# Summary of PCA to see variance explained by each component
summary(pca_result)
names(pca_result)


# Scatter plot of the first two principal components
plot(
    pca_result$x[, 1], pca_result$x[, 2],
    xlab = "PC1", ylab = "PC2",
    main = "PCA Scatter Plot (PC1 vs PC2)",
    pch = 19, xlab.col = "orange", ylab.col = "red"
)

# Plot the proportion of variance explained
plot(pca_result, type = "l", main = "Scree Plot")

# Bar chart of variance explained by each principal component
explained_var <- pca_result$sdev^2 / sum(pca_result$sdev^2)
barplot(
    explained_var,
    names.arg = paste0("PC", 1:length(explained_var)),
    main = "Variance Explained by Principal Components",
    xlab = "Principal Components",
    ylab = "Proportion of Variance Explained",
    col = "skyblue"
)

# Get the loadings (contributions of variables to principal components)
loadings <- pca_result$rotation
head(loadings)

# View the variables that contribute most to the first principal component
head(sort(abs(loadings[,1]), decreasing = TRUE))

# Project the original data onto the first two principal components
pca_scores <- pca_result$x[, 1:2]
head(pca_scores)

# Reduce the dataset to 2 principal components
reduced_data <- as.data.frame(pca_scores)
colnames(reduced_data) <- c("PC1", "PC2")
head(reduced_data)

